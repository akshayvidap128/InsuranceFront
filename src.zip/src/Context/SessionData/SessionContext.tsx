import { createContext } from "react";

const SessionContext = createContext({});

export default SessionContext;
