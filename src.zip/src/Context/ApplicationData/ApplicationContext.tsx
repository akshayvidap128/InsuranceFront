import { createContext } from "react";

const ApplicationContext = createContext({});

export default ApplicationContext;
